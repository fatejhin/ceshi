<script setup lang="ts">
import { GithubOutlined } from '@ant-design/icons-vue'
</script>

<template>
  <a href="https://github.com/antdv-pro/antdv-pro" target="_blank" hover="bg-[var(--hover-color)]" flex items-center h-48px px-12px text-16px class="transition-all-300">
    <GithubOutlined />
  </a>
</template>

<style scoped lang="less">

</style>
