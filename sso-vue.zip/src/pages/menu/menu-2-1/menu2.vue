<script setup lang="ts">

</script>

<template>
  <div>
    Menu2-1-2
    <a-input />
  </div>
</template>
