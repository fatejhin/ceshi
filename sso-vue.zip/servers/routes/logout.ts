export default eventHandler(() => {
  return {
    code: 200,
    msg: 'success',
  }
})
