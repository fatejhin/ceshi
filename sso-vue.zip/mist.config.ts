import { defineConfig } from '@mistjs/cli'

export default defineConfig({
  // 关闭nitro服务
  // nitro: false,
})
