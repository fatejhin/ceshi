<script setup lang="ts">
</script>

<template>
  <div>
    普通用户有权查看 超级管理员同样拥有权限
  </div>
</template>
