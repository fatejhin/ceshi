export default eventHandler(async (_event) => {
  return {
    code: 200,
    msg: '编辑成功',
  }
})
