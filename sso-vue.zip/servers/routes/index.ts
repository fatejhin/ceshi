export default eventHandler(() => {
  return { nitro: 'Hello Antdv Pro' }
})
