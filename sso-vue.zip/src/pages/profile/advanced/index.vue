<script setup lang="ts">
import advancedContainer from './components/advanced-container.vue'

defineOptions({
  name: 'Advanced',
})
</script>

<template>
  <advanced-container />
</template>
